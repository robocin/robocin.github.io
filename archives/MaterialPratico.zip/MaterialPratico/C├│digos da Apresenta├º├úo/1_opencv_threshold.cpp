#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>


cv:: Mat src, dst;
int thresholdValue = 0;

void applyThreshold( int, void* )
{
  cv::threshold( src, dst, thresholdValue, 255, cv::THRESH_BINARY);
 
  cv::imshow( "tela", dst );
}


 
 
int main()
{
  
 
  src = cv::imread( "image.jpg", CV_LOAD_IMAGE_GRAYSCALE );
 
  if (!src.data) {

    std::cout << "Não foi possível abrir ou encontrar a imagem" << std::endl;
    return -1;
  }

  cv::imshow("original",src);
 
  cv::namedWindow( "tela", CV_WINDOW_AUTOSIZE );
 
  cv::createTrackbar( "Trackbar Value", "tela", &thresholdValue, 255, applyThreshold);
 
  applyThreshold( 0, 0 );
 
  while(true)
  {
    int c;
    c = cv::waitKey( 20 );
    if( (char)c == 27 ){ 
      break; 
    }
   }


}
 
 

