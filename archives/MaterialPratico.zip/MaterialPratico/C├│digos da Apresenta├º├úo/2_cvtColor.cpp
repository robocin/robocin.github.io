#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "iostream"
 
// Utilização dos namespaces para usar as funções sem (cv:: ou std::)
using namespace cv;
using namespace std;
 
int main( )
{
       // Criando a matriz da imagem original
       Mat matrizOrigemImagem;

       // Abrindo a imagem original
       matrizOrigemImagem = imread("lena.jpg", CV_LOAD_IMAGE_COLOR);  
 
       if(! matrizOrigemImagem.data )                             
       {
              cout <<  "Could not open or find the image" << std::endl ;
              return -1;
       }
 
       // Criando a matriz de destino da imagem (imagem em tons de cinza)
       Mat matrizDestinoImagem;
 
       // Converter bgr (rgb) para tons de cinza
       cvtColor(matrizOrigemImagem, matrizDestinoImagem, CV_BGR2GRAY);
 
       // Mostrando as imagens
       namedWindow( "Imagem Colorida", CV_WINDOW_AUTOSIZE );  
       imshow( "Imagem Colorida", matrizOrigemImagem );                 
 
       namedWindow( "Imagem em Tons de Cinza", CV_WINDOW_AUTOSIZE );   
       imshow( "Imagem em Tons de Cinza", matrizDestinoImagem );
 
       waitKey(0);


                                                 
       return 0;
}