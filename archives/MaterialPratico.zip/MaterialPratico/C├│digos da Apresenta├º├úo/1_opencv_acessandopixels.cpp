#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

using namespace std;

int main(){

	cv::Mat imagem;

	imagem = cv::imread("imagem1.jpg",CV_LOAD_IMAGE_GRAYSCALE);

	if(!imagem.data){
		cout << "Não foi possível abrir a imagem" << endl;
		return -1;
	}

	// criando um ponteiro legal
	uchar * pointer;

	for (int i=0; i < imagem.rows; i++) {
		// ponteiro recebe o endereço da linha i da imagem
		pointer = imagem.prt<uchar>(i);

		for (int j=0; j < imagem.cols; j++) {
			//acessando a posiçao j do ponteiro com o operador padrão de C
			pointer[j] = pointer[j]/10;

		}

	}

   cv::namedWindow( "window", CV_WINDOW_AUTOSIZE );

   cv::imshow( "window", imagem ); 

   cv::imwrite("result.jpg",imagem);
  
   cv::waitKey(0); 

	return 0;
}