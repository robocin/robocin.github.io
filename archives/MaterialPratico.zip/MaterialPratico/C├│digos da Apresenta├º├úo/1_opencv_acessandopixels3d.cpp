#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

using namespace std;

typedef struct RGB
{
    uchar blue;
    uchar green;
    uchar red;
} RGB;


int main(){

	cv::Mat imagem;

	imagem = cv::imread("imagem1.jpg",CV_LOAD_IMAGE_GRAYSCALE);

	if(!imagem.data){
		cout << "Não foi possível abrir a imagem" << endl;
		return -1;
	}

	// criando um ponteiro legal
	RGB* pointer;

	for (int i=0; i < imagem.rows; i++) {
		
		pointer = imagem.ptr<RGB>(i);

		for (int j=0; j < imagem.cols; j++) {


			pointer[i].red = pointer[i].red/10;

		}

	}

   cv::namedWindow( "window", CV_WINDOW_AUTOSIZE );

   cv::imshow( "window", imagem ); 

   cv::imwrite("result.jpg",imagem);
  
   cv::waitKey(0); 

	return 0;
}