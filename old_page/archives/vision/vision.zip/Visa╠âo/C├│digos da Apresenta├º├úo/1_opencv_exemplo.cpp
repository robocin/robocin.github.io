#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

using namespace std;
 
int main()
{
       // cria uma Mat para guardar a imagem carregada
       cv::Mat imagem;
 
       // Carrega a imagem1
       imagem = cv::imread("image1.jpg", CV_LOAD_IMAGE_COLOR);   

 
       if(! imagem.data )  // Se não houver dados válidos na Mat
       {
              cout <<  "Não foi possível abrir a imagem" << std::endl ;
              return -1;
       }
 
       // cria uma janela
       cv::namedWindow( "window", CV_WINDOW_AUTOSIZE );

       // mostra a imagem na janela "window"
       cv::imshow( "window", imagem ); 
 
       //Salva a imagem num arquivo de nome result.jpg
       cv::imwrite("result.jpg",imagem);
       
       // Espera por input do teclado
       cv::waitKey(0); 

       return 0;
}
