#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "iostream"
 
// Utilização dos namespaces para usar as funções sem (cv:: ou std::)
using namespace cv;
using namespace std;
 
int main( )
{
       // Criando a matriz da imagem original
       Mat matrizOrigemImagem;

       // Abrindo a imagem original
       matrizOrigemImagem = imread("lena.jpg", CV_LOAD_IMAGE_COLOR);  
 
       if(! matrizOrigemImagem.data )                             
       {
              cout <<  "Could not open or find the image" << std::endl ;
              return -1;
       }
 
       // Criando a matriz de destino da imagem (imagem em tons de cinza)
       Mat matrizDestinoImagem;
 
       // Aplicando o Gaussian Blur
       GaussianBlur( matrizOrigemImagem, matrizDestinoImagem, Size( 9, 9 ), 0, 0 );
 
       // Mostrando as imagens
       namedWindow( "Imagem Original", CV_WINDOW_AUTOSIZE );  
       imshow( "Imagem Original", matrizOrigemImagem );                 
 
       namedWindow( "Imagem com filtro Gaussiano", CV_WINDOW_AUTOSIZE );   
       imshow( "Imagem com filtro Gaussiano", matrizDestinoImagem );
 
       waitKey(0);


                                                 
       return 0;
}