#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>

using namespace cv;
using namespace std;
 
int main( int argc, char** argv )
{

    // Criando as matrizes das imagens
    Mat matrizOrigemImagem, matrizDestinoImagem, abs_dst;
    
    // Abrindo a imagem original
    matrizOrigemImagem = imread("lena.jpg", CV_LOAD_IMAGE_COLOR);  

    if(! matrizOrigemImagem.data )                             
    {
          std::cout <<  "Could not open or find the image" << std::endl ;
          return -1;
    }
 
    // Removendo ruído através do filtro Gaussiano
    GaussianBlur( matrizOrigemImagem, matrizOrigemImagem, Size(3,3), 0, 0);

    // Converter bgr (rgb) para tons de cinza
    cvtColor(matrizOrigemImagem, matrizOrigemImagem, CV_BGR2GRAY);

    /// Filtro Laplaciano
    Laplacian( matrizOrigemImagem, matrizDestinoImagem, CV_16S, 3, 1, 0, BORDER_DEFAULT );
    
    // Convertendo a imagem para 8-bits para poder ser mostrada
    convertScaleAbs( matrizDestinoImagem, abs_dst );

    // Mostrando as imagens
    imshow( "Imagem com Filtro Laplaciano", abs_dst ); 
    waitKey(0);



    return 0;
}